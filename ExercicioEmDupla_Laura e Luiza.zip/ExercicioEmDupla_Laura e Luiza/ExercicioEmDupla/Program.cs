﻿// See https://aka.ms/new-console-template for more information
class Program
{
    static void Main(string[] args)
    {
        int opcao = 1;
        while (opcao != 0)
        {
            Console.WriteLine("MENU");

            Console.WriteLine("0 - fechar o programa");
            Console.WriteLine("1 - Somar dois números");
            Console.WriteLine("2 - Transformar metros em milímetros");
            Console.WriteLine("3 - Calcular o aumento");
            Console.WriteLine("4 - Calcular o desconto");
            Console.WriteLine("5 - Aluguel de um carro");
            Console.WriteLine("6 - Calcular o IMC");
            Console.WriteLine("7 - A tabuada de cada número");
            Console.WriteLine("8 - Múltiplos de 3 entre 0 e 10");
            Console.WriteLine("9 - Fatoriais de 1 a 10");
            Console.WriteLine("10 - Calcular o imposto de renda");
            Console.WriteLine("11 - Adivinhe o número");
            Console.WriteLine("12 - Calcular o financiamento de um veículo");
            Console.WriteLine("13 - Calcular a aposentadoria");
            Console.WriteLine("Escolha uma opção: ");
            opcao = int.Parse(Console.ReadLine());


            switch (opcao)
            {
                case 0:
                    return;
                case 1:
                    FuncaoSoma();
                    break;
                case 2:
                    FuncaoMparaMm();

                    break;
                case 3:
                    FuncaoAumento();

                    break;
                case 4:
                    FuncaoDesconto();

                    break;
                case 5:
                    FuncaoAluguel();

                    break;
                case 6:
                    FuncaoImc();

                    break;
                case 7:
                    FuncaoTabuada();

                    break;
                case 8:
                    FuncaoMultiplos();

                    break;
                case 9:
                    FuncaoFatorial();

                    break;
                case 10:
                    FuncaoImpostoRenda();

                    break;
                case 11:
                    FuncaoAdvinharNumero();

                    break;
                case 12:
                    FuncaoFinanciamento();

                    break;
                case 13:
                    FuncaoAposentadoria();

                    break;
                default:
                    Console.WriteLine("Opção não encontrada");
                    break;

            }
        }

        void FuncaoSoma()
        {
            int soma, n1, n2;

            Console.WriteLine("Digite um número: ");
            n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite outro número: ");
            n2 = int.Parse(Console.ReadLine());

            soma = n1 + n2;
            Console.WriteLine($"A soma dos números é: {soma}");

        }
        void FuncaoMparaMm()
        {
            Console.WriteLine("Digite um valor em metros: ");
            float metro = float.Parse(Console.ReadLine());
            double milimetros = metro * 1000;
            Console.WriteLine($"O valor digitado em milímetros é: {milimetros} ");

        }
        void FuncaoAumento()
        {
            Console.WriteLine("Informe o valor: ");
            double valor = double.Parse(Console.ReadLine());
            Console.WriteLine("Informe o percentual de aumento: ");
            double porcentagemAumento = double.Parse(Console.ReadLine()) / 100;
            double percentualAumento = valor * porcentagemAumento;
            Console.WriteLine($"Percentual de aumento é {percentualAumento}");
            double novoValor = valor + percentualAumento;
            Console.WriteLine($"O novo valor é: {novoValor}");
            Console.WriteLine($"O valor inicial é {valor}");

        }
        void FuncaoDesconto()
        {
            Console.WriteLine("Informe o valor:");
            float valor1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Informe a porcentagem do desconto: ");
            float desconto = float.Parse(Console.ReadLine());
            float ValorComDesconto = valor1 - (valor1 * desconto) / 100;
            Console.WriteLine($"Valor com desconto igual a {ValorComDesconto}");
            Console.WriteLine($"Valor sem desconto {valor1}");
            Console.WriteLine($"Desconto foi de {desconto}%");
        }
        void FuncaoAluguel()
        {
            Console.WriteLine("Informe o número de dias");
            byte numDias = byte.Parse(Console.ReadLine());
            Console.WriteLine("Informe o quilometro inicial");
            double KmInicial =
            double.Parse(Console.ReadLine());
            Console.WriteLine("Informe o Km final: ");
            double KmFinal = double.Parse(Console.ReadLine());

            int ValorDeDia = numDias * 95;
            double valorKm = (KmFinal - KmInicial) * 0.35;
            double total = valorKm + ValorDeDia;
            Console.WriteLine($"Valor a ser pago é: {total}");


        }
        void FuncaoImc()
        {
            Console.WriteLine("Digite a altura em metros : ");
            float Altura = float.Parse(Console.ReadLine());
            Console.WriteLine("Digite o peso em kg : ");
            float peso = float.Parse(Console.ReadLine());
            float imc = peso / (Altura * Altura);
            Console.WriteLine($"O seu índice de massa corporal é igual: {imc}");
            if (imc < 18.5)
            {
                Console.WriteLine("Abaixo do peso");
            }
            else if (imc <= 24.9)
            {
                Console.WriteLine("Peso ideal");
            }
            else if (imc <= 29.9)
            {
                Console.WriteLine("Levemente acima do peso");
            }
            else if (imc <= 34.9)
            {
                Console.WriteLine("Obesidade grau 1");
            }
            else if (imc <= 39.9)
            {
                Console.WriteLine("Obesidade grau 2");
            }
            else if (imc >= 40)
            {
                Console.WriteLine("Obesidade mórbida");
            }
        }
        void FuncaoTabuada()
        {
            int tabuada, contador, numero;

            Console.Write("Digite o numero da tabuada desejada: ");
            numero = int.Parse(Console.ReadLine());

            for (contador = 1; contador <= 10; ++contador)
            {
                tabuada = numero * contador;
                Console.WriteLine(numero + " X " + contador + " = " + tabuada);

            }

        }
        void FuncaoMultiplos()
        {
            {
                float[] multiplos = new float[101];
                multiplos[0] = 3;
                for (int i = 1; i < multiplos.Length; i++)
                {
                    multiplos[i] = i + 1;
                    if (i % 3 == 0)
                    {
                        Console.WriteLine("É  multiplo de 3 " + i);
                    }

                }
                Console.WriteLine("Esses são os multiplos de 3");
            }
        }
        void FuncaoFatorial()
        {
            float[] fatorial = new float[11];
            fatorial[0] = 1;

            for (int i = 1; i < fatorial.Length; i++)
            {
                fatorial[i] = fatorial[i - 1] * i;
                Console.WriteLine($"O fatorial de: {i} é: {fatorial[i]}");
            }
        }
        void FuncaoImpostoRenda()
        {
            Console.WriteLine("Diga seu salario: ");
            double valorBruto = double.Parse(Console.ReadLine());
            if (valorBruto < 1903.98)
            {
                Console.WriteLine("Não recebe desconto");
            }
            else
                if (valorBruto <= 2826.65)
            {
                double porcentagemDesconto = 7.5 / 100;
                double salarioDesconto = valorBruto - (valorBruto * porcentagemDesconto);
                Console.WriteLine($"O seu salário com desconto igual a {salarioDesconto}");
                double apagar = valorBruto * porcentagemDesconto;
                Console.WriteLine($" Ovalor a pagar = {apagar}");
            }
            else
                if (valorBruto <= 3751.05)
            {
                double porcentagemDesconto = 15.0 / 100;
                double salarioDesconto = valorBruto - (valorBruto * porcentagemDesconto);
                Console.WriteLine($"O seu salário com desconto igual a {salarioDesconto}");
                double apagar = valorBruto * porcentagemDesconto;
                Console.WriteLine($"O valor a pagar = {apagar}");

            }
            else
                    if (valorBruto <= 4664.68)
            {
                double porcentagemDesconto = 22.5 / 100;
                double salarioDesconto = valorBruto - (valorBruto * porcentagemDesconto);
                Console.WriteLine($"o salario com desconto igual a {salarioDesconto}");
                double apagar = valorBruto * porcentagemDesconto;
                Console.WriteLine($"O valor a pagar = {apagar}");
            }
            else
                    if (valorBruto > 4664.68)
            {
                double porcentagemDesconto = 27.5 / 100;
                double salarioDesconto = valorBruto - (valorBruto * porcentagemDesconto);
                Console.WriteLine($"O salario com desconto igual a {salarioDesconto}");
                double apagar = valorBruto * porcentagemDesconto;
                Console.WriteLine($"O valor a pagar = {apagar}");
            }
        }
        void FuncaoAdvinharNumero()
        {
            int tentativas = 0;
            int n3 = 0;
            Random r = new Random();
            int a = r.Next(0, 100);
            while (true)
            {
                tentativas++;

                Console.WriteLine("Advinhe o numero!");
                try
                {
                    n3 = int.Parse(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Um número, não uma letra.");
                }
                if (n3 < a)
                {
                    Console.WriteLine($"Ele é maior que {n3}");
                }
                else
                    if (n3 > a)
                {
                    Console.WriteLine($"Ele é menor que {n3}");
                }
                if (tentativas >= 10)
                {
                    Console.WriteLine($"Incorreto, o número era {a}");

                    break;
                }
                if (n3 == a)
                {
                    Console.WriteLine($"Acertou depois de {tentativas} tentativas.");

                    break;

                }

            }
        }
        void FuncaoFinanciamento()
        {
            double DivisaoDeVeiculo = 0, taxa = 0, total = 0;
            Console.WriteLine("Digite o valor do veiculo");
            double valordoVeiculo = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite o numero de parcelas");
            double NumerodasParcelas = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite a taxa mensal ");
            double taxaM = double.Parse(Console.ReadLine()) / 100;
            double juros = valordoVeiculo * taxaM * NumerodasParcelas;
            double juroSimples = valordoVeiculo + juros;
            for (int i = 0; i <= NumerodasParcelas; i++)
            {
                juros *= 1 + taxaM;
            }

            double dinheiro = valordoVeiculo + juros;
            Console.WriteLine("Valor do Veiculo Total igual a :" + juros);
            Console.WriteLine("Valor juros simples" + juroSimples);
        }
        void FuncaoAposentadoria()
        {
            double JurosComposto = 0;
            double Acumulador = 0;
            double Montante = 0;
            Console.WriteLine("Informe a idade ");
            double Idade = int.Parse(Console.ReadLine());
            Console.WriteLine("Informe a idade para se aposentar ");
            double IdadeFinal = int.Parse(Console.ReadLine());
            Console.WriteLine("informe um valor para investir ");
            double ValorAposentadoria = double.Parse(Console.ReadLine());
            double TaxaRendimento = 0.01;
            double AnosRendimento = (IdadeFinal - Idade) * 12;

            for (double i = 0; i <= AnosRendimento; i++)
            {
                Acumulador = Acumulador + ValorAposentadoria;
                JurosComposto = JurosComposto + (Acumulador * 0.01);
                Montante = Acumulador + JurosComposto;

            }

            double SalarioLiquido = Montante * TaxaRendimento;
            Console.WriteLine("Montante igual a " + Montante);
            Console.WriteLine($"Salario liquido igual a {SalarioLiquido}");
        }
    }
}


